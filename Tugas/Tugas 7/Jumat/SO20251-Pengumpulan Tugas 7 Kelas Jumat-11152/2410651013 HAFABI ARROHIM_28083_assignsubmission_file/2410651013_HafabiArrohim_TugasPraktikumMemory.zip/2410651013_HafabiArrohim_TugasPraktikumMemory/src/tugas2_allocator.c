#include <stdio.h>

#define MAX_BLOCKS 5

int memory[MAX_BLOCKS] = {100, 500, 200, 300, 600};
int last_index = 0;

/* ================= NEXT-FIT ================= */
int next_fit(int process_size) {
    int start = last_index;
    int i = start;

    do {
        if (memory[i] >= process_size) {
            memory[i] -= process_size;
            last_index = i;
            return i;
        }
        i = (i + 1) % MAX_BLOCKS;
    } while (i != start);

    return -1;
}

/* ================= FRAGMENTATION ================= */
void calculate_fragmentation() {
    int total_free = 0;
    int largest_free = 0;
    int free_blocks = 0;

    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (memory[i] > 0) {
            total_free += memory[i];
            free_blocks++;
            if (memory[i] > largest_free)
                largest_free = memory[i];
        }
    }

    float fragmentation_ratio =
        (float)(total_free - largest_free) / total_free;

    printf("Total free space      : %d\n", total_free);
    printf("Largest free block    : %d\n", largest_free);
    printf("Number of free blocks : %d\n", free_blocks);
    printf("Fragmentation ratio   : %.2f\n", fragmentation_ratio);
}

/* ================= BENCHMARK ================= */
void benchmark_test() {
    int processes[] = {100, 200, 300, 250, 150};
    int n = sizeof(processes) / sizeof(processes[0]);

    for (int i = 0; i < n; i++) {
        int index = next_fit(processes[i]);
        if (index != -1)
            printf("Process %d allocated at block %d\n",
                   processes[i], index);
        else
            printf("Process %d cannot be allocated\n", processes[i]);
    }

    calculate_fragmentation();
}

int main() {
    printf("=== Next-Fit Memory Allocation ===\n");

    benchmark_test();

    return 0;
}
