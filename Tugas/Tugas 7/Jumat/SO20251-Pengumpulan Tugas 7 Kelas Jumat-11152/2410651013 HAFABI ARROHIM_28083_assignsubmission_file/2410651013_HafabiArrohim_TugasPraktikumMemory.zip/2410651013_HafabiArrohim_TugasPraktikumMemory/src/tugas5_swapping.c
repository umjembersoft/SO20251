#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_PROCESSES 10
#define MEMORY_SIZE 1024

typedef struct {
    int pid;
    int size;           // MB
    int priority;       // kecil = penting
    int in_memory;      // 1 = RAM, 0 = swap
    int swap_count;
    int last_access;
    int load_time;
} Process;

Process processes[MAX_PROCESSES];
int used_memory = 0;
int current_time = 0;

/* Swap out process */
void swap_out(Process *p) {
    if (p->in_memory) {
        p->in_memory = 0;
        used_memory -= p->size;
        p->swap_count++;
        printf("SWAP OUT: PID %d (size=%dMB)\n", p->pid, p->size);
    }
}

/* Swap in process */
void swap_in(Process *p) {
    p->in_memory = 1;
    p->load_time = current_time;
    p->last_access = current_time;
    used_memory += p->size;
    printf("SWAP IN : PID %d (size=%dMB)\n", p->pid, p->size);
}

/* FIFO strategy */
int select_fifo() {
    int idx = -1;
    int oldest = 1e9;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].in_memory && processes[i].load_time < oldest) {
            oldest = processes[i].load_time;
            idx = i;
        }
    }
    return idx;
}

/* LRU strategy */
int select_lru() {
    int idx = -1;
    int least = 1e9;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].in_memory && processes[i].last_access < least) {
            least = processes[i].last_access;
            idx = i;
        }
    }
    return idx;
}

/* Priority-based strategy */
int select_priority() {
    int idx = -1;
    int lowest_priority = -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].in_memory && processes[i].priority > lowest_priority) {
            lowest_priority = processes[i].priority;
            idx = i;
        }
    }
    return idx;
}

/* Initialize processes */
void init_processes() {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        processes[i].pid = i + 1;
        processes[i].size = 150 + rand() % 51; // 150–200 MB
        processes[i].priority = rand() % 5;
        processes[i].in_memory = 0;
        processes[i].swap_count = 0;
        processes[i].last_access = 0;
        processes[i].load_time = 0;
    }
}

/* Simulation */
void simulate(int strategy) {
    used_memory = 0;
    current_time = 0;

    for (int i = 0; i < 100; i++) {
        current_time++;
        int idx = rand() % MAX_PROCESSES;

        if (!processes[idx].in_memory) {
            while (used_memory + processes[idx].size > MEMORY_SIZE) {
                int victim;
                if (strategy == 1)
                    victim = select_fifo();
                else if (strategy == 2)
                    victim = select_lru();
                else
                    victim = select_priority();

                if (victim == -1) break;
                swap_out(&processes[victim]);
            }
            swap_in(&processes[idx]);
        }

        processes[idx].last_access = current_time;
    }
}

/* Main */
int main() {
    srand(time(NULL));
    init_processes();

    printf("\n=== FIFO STRATEGY ===\n");
    simulate(1);

    init_processes();
    printf("\n=== LRU STRATEGY ===\n");
    simulate(2);

    init_processes();
    printf("\n=== PRIORITY STRATEGY ===\n");
    simulate(3);

    return 0;
}

