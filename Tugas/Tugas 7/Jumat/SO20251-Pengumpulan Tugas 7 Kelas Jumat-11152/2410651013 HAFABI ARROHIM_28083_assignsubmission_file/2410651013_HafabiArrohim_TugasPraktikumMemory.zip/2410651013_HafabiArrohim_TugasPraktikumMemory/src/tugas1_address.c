#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Global variable (Data Segment)
int global_var = 10;

// Functions (Text Segment)
void func1() {}
void func2() {}
void func3() {}

// Recursive function (Stack)
void recursive(int level) {
    int local_var;
    printf("Level %d local_var address: %p\n",
           level, (void*)&local_var);

    if (level > 0)
        recursive(level - 1);
}

int main() {
    printf("ENHANCED MEMORY LAYOUT\n\n");

    /* ================= TEXT SEGMENT ================= */
    printf("1. Text Segment:\n");
    printf("main() address  : %p\n", (void*)main);
    printf("func1() address : %p\n", (void*)func1);
    printf("func2() address : %p\n\n", (void*)func2);

    /* ================= DATA SEGMENT ================= */
    printf("2. Data Segment:\n");
    static int static_array[5];
    printf("static_array[0] address: %p\n", (void*)&static_array[0]);

    char *str = "Hello Memory";
    printf("string literal address : %p\n\n", (void*)str);

    /* ================= HEAP ================= */
    printf("3. Heap:\n");
    int *dynamic_array = (int*)malloc(5 * sizeof(int));
    int *block1 = (int*)malloc(10);
    int *block2 = (int*)malloc(20);

    printf("dynamic_array[0] address: %p\n", (void*)&dynamic_array[0]);
    printf("malloc block 1 address : %p\n", (void*)block1);
    printf("malloc block 2 address : %p\n\n", (void*)block2);

    /* ================= STACK ================= */
    printf("4. Stack (Recursive Calls):\n");
    recursive(2);

    free(dynamic_array);
    free(block1);
    free(block2);

    return 0;
}

