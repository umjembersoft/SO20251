#include <stdio.h>

#define FRAMES 3
#define PAGES 20

typedef struct {
    int total_accesses;
    int page_faults;
    int page_hits;
    int disk_writes;
} PageStatistics;

/* ================= FIFO ================= */
int fifo(int pages[], int n, PageStatistics *stats) {
    int frame[FRAMES], index = 0;
    for (int i = 0; i < FRAMES; i++) frame[i] = -1;

    for (int i = 0; i < n; i++) {
        stats->total_accesses++;
        int hit = 0;

        for (int j = 0; j < FRAMES; j++)
            if (frame[j] == pages[i]) hit = 1;

        if (hit) {
            stats->page_hits++;
        } else {
            stats->page_faults++;
            frame[index] = pages[i];
            index = (index + 1) % FRAMES;
            stats->disk_writes++;
        }
    }
    return 0;
}

/* ================= LRU ================= */
int findLRU(int time[], int n) {
    int min = time[0], pos = 0;
    for (int i = 1; i < n; i++) {
        if (time[i] < min) {
            min = time[i];
            pos = i;
        }
    }
    return pos;
}

int lru(int pages[], int n, PageStatistics *stats) {
    int frame[FRAMES], time[FRAMES];
    for (int i = 0; i < FRAMES; i++) frame[i] = -1;

    int counter = 0;
    for (int i = 0; i < n; i++) {
        stats->total_accesses++;
        int hit = 0;

        for (int j = 0; j < FRAMES; j++) {
            if (frame[j] == pages[i]) {
                hit = 1;
                counter++;
                time[j] = counter;
                stats->page_hits++;
            }
        }

        if (!hit) {
            stats->page_faults++;
            int pos = -1;
            for (int j = 0; j < FRAMES; j++) {
                if (frame[j] == -1) {
                    pos = j;
                    break;
                }
            }
            if (pos == -1)
                pos = findLRU(time, FRAMES);

            frame[pos] = pages[i];
            counter++;
            time[pos] = counter;
            stats->disk_writes++;
        }
    }
    return 0;
}

/* ================= DISPLAY ================= */
void display_stats(char *name, PageStatistics s) {
    printf("\n=== %s ===\n", name);
    printf("Total Accesses : %d\n", s.total_accesses);
    printf("Page Faults    : %d\n", s.page_faults);
    printf("Page Hits      : %d\n", s.page_hits);
    printf("Hit Ratio      : %.2f\n",
           (float)s.page_hits / s.total_accesses);
    printf("Disk Writes    : %d\n", s.disk_writes);
}

int main() {
    int reference_string[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int n = sizeof(reference_string) / sizeof(reference_string[0]);

    PageStatistics fifo_stats = {0};
    PageStatistics lru_stats = {0};

    fifo(reference_string, n, &fifo_stats);
    lru(reference_string, n, &lru_stats);

    display_stats("FIFO", fifo_stats);
    display_stats("LRU", lru_stats);

    return 0;
}
