#include <stdio.h>
#include <stdlib.h>

#define L1_BITS 16
#define L2_BITS 8
#define L3_BITS 8
#define OFFSET_BITS 12

#define L1_SIZE (1 << L1_BITS)
#define L2_SIZE (1 << L2_BITS)
#define L3_SIZE (1 << L3_BITS)

typedef struct {
    int frame_number;
    int valid;
    int read;
    int execute;
} L3Entry;

typedef struct {
    L3Entry *entries;
    int valid;
} L2Entry;

typedef struct {
    L2Entry *entries;
    int valid;
} L1Entry;

L1Entry *page_table;

/* Allocate page table levels */
void allocate_levels(unsigned long virtual_addr) {
    unsigned long l1 = (virtual_addr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & ((1 << L1_BITS) - 1);
    unsigned long l2 = (virtual_addr >> (L3_BITS + OFFSET_BITS)) & ((1 << L2_BITS) - 1);
    unsigned long l3 = (virtual_addr >> OFFSET_BITS) & ((1 << L3_BITS) - 1);

    if (!page_table[l1].valid) {
        page_table[l1].entries = calloc(L2_SIZE, sizeof(L2Entry));
        page_table[l1].valid = 1;
    }

    if (!page_table[l1].entries[l2].valid) {
        page_table[l1].entries[l2].entries = calloc(L3_SIZE, sizeof(L3Entry));
        page_table[l1].entries[l2].valid = 1;
    }

    page_table[l1].entries[l2].entries[l3].frame_number = rand() % 1024;
    page_table[l1].entries[l2].entries[l3].valid = 1;
}

/* Translate virtual to physical */
int translate(unsigned long virtual_addr) {
    unsigned long l1 = (virtual_addr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & ((1 << L1_BITS) - 1);
    unsigned long l2 = (virtual_addr >> (L3_BITS + OFFSET_BITS)) & ((1 << L2_BITS) - 1);
    unsigned long l3 = (virtual_addr >> OFFSET_BITS) & ((1 << L3_BITS) - 1);

    if (!page_table[l1].valid) return -1;
    if (!page_table[l1].entries[l2].valid) return -1;
    if (!page_table[l1].entries[l2].entries[l3].valid) return -1;

    return page_table[l1].entries[l2].entries[l3].frame_number;
}

/* Memory overhead calculation */
void calculate_memory_overhead() {
    int l1_count = 0, l2_count = 0, l3_count = 0;

    for (int i = 0; i < L1_SIZE; i++) {
        if (page_table[i].valid) {
            l1_count++;
            for (int j = 0; j < L2_SIZE; j++) {
                if (page_table[i].entries[j].valid) {
                    l2_count++;
                    for (int k = 0; k < L3_SIZE; k++) {
                        if (page_table[i].entries[j].entries[k].valid)
                            l3_count++;
                    }
                }
            }
        }
    }

    printf("L1 entries used: %d\n", l1_count);
    printf("L2 entries used: %d\n", l2_count);
    printf("L3 entries used: %d\n", l3_count);
}

int main() {
    page_table = calloc(L1_SIZE, sizeof(L1Entry));

    unsigned long addr1 = 0x123456789A;
    unsigned long addr2 = 0xABCDEFFF12;

    allocate_levels(addr1);
    allocate_levels(addr2);

    printf("Translate addr1: Frame %d\n", translate(addr1));
    printf("Translate addr2: Frame %d\n", translate(addr2));

    calculate_memory_overhead();
    return 0;
}
