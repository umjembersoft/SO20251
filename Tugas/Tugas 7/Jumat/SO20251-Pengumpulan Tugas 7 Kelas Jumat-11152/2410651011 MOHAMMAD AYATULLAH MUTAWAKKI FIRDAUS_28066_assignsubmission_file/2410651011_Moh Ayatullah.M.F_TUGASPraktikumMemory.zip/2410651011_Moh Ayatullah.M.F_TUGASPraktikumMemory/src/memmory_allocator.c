#include <stdio.h>
#include <string.h>
#include <time.h>

#define MEMORY_SIZE 1000
#define MAX_PROCESS 20

typedef struct {
    char name[10];
    int size;
    int start;
    int allocated;
} Process;

int memory[MEMORY_SIZE];
Process plist[MAX_PROCESS];
int pcount = 0;
int last_position = 0;

/* ================== INIT ================== */
void init_memory() {
    for (int i = 0; i < MEMORY_SIZE; i++)
        memory[i] = MEMORY_SIZE;
}

/* ================== ALGORITHMS ================== */
int first_fit(int size) {
    for (int i = 0; i < MEMORY_SIZE; i++)
        if (memory[i] >= size)
            return i;
    return -1;
}

int best_fit(int size) {
    int best = -1;
    for (int i = 0; i < MEMORY_SIZE; i++)
        if (memory[i] >= size &&
           (best == -1 || memory[i] < memory[best]))
            best = i;
    return best;
}

int worst_fit(int size) {
    int worst = -1;
    for (int i = 0; i < MEMORY_SIZE; i++)
        if (memory[i] >= size &&
           (worst == -1 || memory[i] > memory[worst]))
            worst = i;
    return worst;
}

int next_fit(int size) {
    for (int i = last_position; i < MEMORY_SIZE; i++)
        if (memory[i] >= size) {
            last_position = i;
            return i;
        }

    for (int i = 0; i < last_position; i++)
        if (memory[i] >= size) {
            last_position = i;
            return i;
        }
    return -1;
}

/* ================== ALLOC / DEALLOC ================== */
void allocate(char *name, int size, int algo) {
    int pos = -1;

    if (algo == 1) pos = first_fit(size);
    else if (algo == 2) pos = best_fit(size);
    else if (algo == 3) pos = worst_fit(size);
    else if (algo == 4) pos = next_fit(size);

    if (pos == -1) {
        printf("%s gagal dialokasikan\n", name);
        return;
    }

    memory[pos] -= size;
    strcpy(plist[pcount].name, name);
    plist[pcount].size = size;
    plist[pcount].start = pos;
    plist[pcount].allocated = 1;
    pcount++;

    printf("%s dialokasikan (%d KB)\n", name, size);
}

void deallocate(char *name) {
    for (int i = 0; i < pcount; i++) {
        if (strcmp(plist[i].name, name) == 0 && plist[i].allocated) {
            memory[plist[i].start] += plist[i].size;
            plist[i].allocated = 0;
            printf("%s dibebaskan\n", name);
            return;
        }
    }
}

/* ================== FRAGMENTATION ================== */
void calculate_fragmentation() {
    int total_free = 0, largest = 0, holes = 0;

    for (int i = 0; i < MEMORY_SIZE; i++) {
        if (memory[i] > 0) {
            total_free += memory[i];
            holes++;
            if (memory[i] > largest)
                largest = memory[i];
        }
    }

    float frag = 0;
    if (total_free > 0)
        frag = (float)(total_free - largest) / total_free * 100;

    printf("Fragmentasi: %.2f %%\n", frag);
}

/* ================== BENCHMARK ================== */
void benchmark(int algo) {
    init_memory();
    pcount = 0;
    last_position = 0;

    clock_t start = clock();

    allocate("P1",100,algo);
    allocate("P2",200,algo);
    allocate("P3",300,algo);
    allocate("P4",250,algo);
    allocate("P5",150,algo);

    deallocate("P2");
    deallocate("P4");

    allocate("P6",180,algo);
    allocate("P7",220,algo);
    allocate("P8",100,algo);

    clock_t end = clock();
    double time = (double)(end - start) / CLOCKS_PER_SEC * 1e6;

    calculate_fragmentation();
    printf("Waktu: %.2f µs\n\n", time);
}

/* ================== MAIN ================== */
int main() {
    printf("First-Fit\n");   benchmark(1);
    printf("Best-Fit\n");    benchmark(2);
    printf("Worst-Fit\n");   benchmark(3);
    printf("Next-Fit\n");    benchmark(4);
    return 0;
}
