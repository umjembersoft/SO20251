#include <stdio.h>

#define FRAMES 4
#define REF_LEN 20

typedef struct {
    int page;
    int dirty;
    int last_used;
} Frame;

typedef struct {
    int total_accesses;
    int page_faults;
    int page_hits;
    float hit_ratio;
    int disk_writes;
} PageStatistics;

Frame frames[FRAMES];
int fifo_index = 0;
int time_counter = 0;

/* ================= INIT ================= */
void init_frames() {
    for (int i = 0; i < FRAMES; i++) {
        frames[i].page = -1;
        frames[i].dirty = 0;
        frames[i].last_used = 0;
    }
}

/* ================= FIFO ================= */
int fifo_page_replacement(int new_page, PageStatistics *stats) {
    int evict = fifo_index;

    if (frames[evict].dirty)
        stats->disk_writes++;

    frames[evict].page = new_page;
    frames[evict].dirty = 1;
    frames[evict].last_used = time_counter++;

    fifo_index = (fifo_index + 1) % FRAMES;
    return evict;
}

/* ================= LRU ================= */
int lru_page_replacement(int new_page, PageStatistics *stats) {
    int lru = 0;

    for (int i = 1; i < FRAMES; i++)
        if (frames[i].last_used < frames[lru].last_used)
            lru = i;

    if (frames[lru].dirty)
        stats->disk_writes++;

    frames[lru].page = new_page;
    frames[lru].dirty = 1;
    frames[lru].last_used = time_counter++;

    return lru;
}

/* ================= CHECK HIT ================= */
int find_page(int page) {
    for (int i = 0; i < FRAMES; i++)
        if (frames[i].page == page)
            return i;
    return -1;
}

/* ================= STATISTICS ================= */
void display_statistics(PageStatistics *stats) {
    stats->hit_ratio =
        (float)stats->page_hits / stats->total_accesses;

    printf("Total Accesses : %d\n", stats->total_accesses);
    printf("Page Faults   : %d\n", stats->page_faults);
    printf("Page Hits     : %d\n", stats->page_hits);
    printf("Hit Ratio     : %.2f\n", stats->hit_ratio);
    printf("Disk Writes   : %d\n", stats->disk_writes);
}

/* ================= SIMULATION ================= */
void simulate(int ref[], int use_lru) {
    PageStatistics stats = {0,0,0,0,0};
    init_frames();
    fifo_index = 0;
    time_counter = 0;

    for (int i = 0; i < REF_LEN; i++) {
        stats.total_accesses++;
        int page = ref[i];

        int pos = find_page(page);
        if (pos != -1) {
            stats.page_hits++;
            frames[pos].last_used = time_counter++;
        } else {
            stats.page_faults++;
            int empty = find_page(-1);
            if (empty != -1) {
                frames[empty].page = page;
                frames[empty].dirty = 1;
                frames[empty].last_used = time_counter++;
            } else {
                if (use_lru)
                    lru_page_replacement(page, &stats);
                else
                    fifo_page_replacement(page, &stats);
            }
        }
    }

    display_statistics(&stats);
}

/* ================= MAIN ================= */
int main() {
    int reference_string[REF_LEN] =
        {7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};

    printf("=== FIFO ===\n");
    simulate(reference_string, 0);

    printf("\n=== LRU ===\n");
    simulate(reference_string, 1);

    return 0;
}
