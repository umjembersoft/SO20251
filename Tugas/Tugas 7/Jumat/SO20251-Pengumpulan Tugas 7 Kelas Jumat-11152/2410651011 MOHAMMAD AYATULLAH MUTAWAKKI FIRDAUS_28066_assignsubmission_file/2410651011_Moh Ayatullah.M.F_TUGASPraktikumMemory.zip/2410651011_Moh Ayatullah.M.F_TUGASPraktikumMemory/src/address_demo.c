#include <stdio.h>
#include <stdlib.h>

// Data Segment
int global_var = 100;
static int static_array[3] = {1, 2, 3};

void func1() {
    printf("func1() address           : %p\n", func1);
}

void func2() {
    printf("func2() address           : %p\n", func2);
}

// Stack (Recursive)
void recursive(int level) {
    int local_var = level;
    printf("Level %d local_var address: %p\n", level, &local_var);

    if (level < 2)
        recursive(level + 1);
}

int main() {

    printf("=== TEXT SEGMENT ===\n");
    printf("main() address            : %p\n", main);
    func1();
    func2();

    printf("\n=== DATA SEGMENT ===\n");
    printf("static_array[0] address   : %p\n", &static_array[0]);
    printf("string_literal address    : %p\n", "Hello Memory");

    printf("\n=== HEAP ===\n");
    int *dynamic_array = (int*) malloc(3 * sizeof(int));
    int *block1 = (int*) malloc(50);
    int *block2 = (int*) malloc(50);

    printf("dynamic_array[0] address  : %p\n", &dynamic_array[0]);
    printf("malloc block 1            : %p\n", block1);
    printf("malloc block 2            : %p\n", block2);

    printf("\n=== STACK (RECURSIVE CALLS) ===\n");
    recursive(0);

    free(dynamic_array);
    free(block1);
    free(block2);

    return 0;
}

