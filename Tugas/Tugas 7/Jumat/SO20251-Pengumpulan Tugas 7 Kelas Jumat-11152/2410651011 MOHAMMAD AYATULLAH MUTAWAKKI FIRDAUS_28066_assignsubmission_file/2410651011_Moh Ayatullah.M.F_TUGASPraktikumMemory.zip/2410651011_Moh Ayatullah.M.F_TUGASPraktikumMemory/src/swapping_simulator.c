#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_PROCESS 10
#define MEMORY_SIZE 1024

typedef struct {
    int pid;
    int size;
    int priority;
    int in_memory;
    int swap_count;
    time_t last_access;
    time_t load_time;
} Process;

Process processes[MAX_PROCESS];
int used_memory = 0;

/* ---------- SWAP FUNCTIONS ---------- */

void swap_out(Process *p) {
    p->in_memory = 0;
    used_memory -= p->size;
    p->swap_count++;
}

void swap_in(Process *p) {
    p->in_memory = 1;
    used_memory += p->size;
    p->last_access = time(NULL);
    p->load_time = time(NULL);
}

/* ---------- VICTIM SELECTION ---------- */

Process* select_fifo() {
    Process *victim = NULL;
    for (int i = 0; i < MAX_PROCESS; i++) {
        if (processes[i].in_memory) {
            if (!victim || processes[i].load_time < victim->load_time)
                victim = &processes[i];
        }
    }
    return victim;
}

Process* select_lru() {
    Process *victim = NULL;
    for (int i = 0; i < MAX_PROCESS; i++) {
        if (processes[i].in_memory) {
            if (!victim || processes[i].last_access < victim->last_access)
                victim = &processes[i];
        }
    }
    return victim;
}

Process* select_priority() {
    Process *victim = NULL;
    for (int i = 0; i < MAX_PROCESS; i++) {
        if (processes[i].in_memory) {
            if (!victim || processes[i].priority < victim->priority)
                victim = &processes[i];
        }
    }
    return victim;
}

/* ---------- MAIN SIMULATION ---------- */

int main() {
    srand(time(NULL));

    for (int i = 0; i < MAX_PROCESS; i++) {
        processes[i].pid = i;
        processes[i].size = 50 + rand() % 150;
        processes[i].priority = rand() % 10;
        processes[i].in_memory = 0;
        processes[i].swap_count = 0;
    }

    for (int t = 0; t < 100; t++) {
        int pid = rand() % MAX_PROCESS;
        Process *p = &processes[pid];

        if (!p->in_memory) {
            while (used_memory + p->size > MEMORY_SIZE) {
                Process *victim = select_lru(); // ganti FIFO / PRIORITY
                swap_out(victim);
            }
            swap_in(p);
        }
        p->last_access = time(NULL);
    }

    printf("Simulation Finished\n");
    for (int i = 0; i < MAX_PROCESS; i++) {
        printf("PID %d - Swap Count: %d\n", i, processes[i].swap_count);
    }

    return 0;
}
