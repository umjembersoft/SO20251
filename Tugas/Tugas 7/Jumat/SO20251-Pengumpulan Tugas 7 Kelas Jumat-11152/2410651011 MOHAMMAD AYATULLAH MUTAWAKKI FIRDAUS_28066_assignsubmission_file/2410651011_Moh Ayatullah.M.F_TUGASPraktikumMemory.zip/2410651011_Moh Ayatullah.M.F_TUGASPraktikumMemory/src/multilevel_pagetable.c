#include <stdio.h>
#include <stdlib.h>

#define L1_BITS 16
#define L2_BITS 8
#define L3_BITS 8
#define OFFSET_BITS 12

#define NUM_FRAMES 64

/* ---------- THREE LEVEL PAGE TABLE ---------- */

typedef struct {
    int frame_number;
    int valid;
    int read;
    int write;
    int execute;
} L3_Entry;

typedef struct {
    L3_Entry *entries;
    int valid;
} L2_Entry;

typedef struct {
    L2_Entry *entries;
    int valid;
} L1_Entry;

L1_Entry *page_table_l1 = NULL;

void allocate_3level(unsigned long vaddr, int frame) {
    unsigned long l1 = (vaddr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & 0xFFFF;
    unsigned long l2 = (vaddr >> (L3_BITS + OFFSET_BITS)) & 0xFF;
    unsigned long l3 = (vaddr >> OFFSET_BITS) & 0xFF;

    if (!page_table_l1) {
        page_table_l1 = calloc(1 << L1_BITS, sizeof(L1_Entry));
    }

    if (!page_table_l1[l1].valid) {
        page_table_l1[l1].entries = calloc(1 << L2_BITS, sizeof(L2_Entry));
        page_table_l1[l1].valid = 1;
    }

    if (!page_table_l1[l1].entries[l2].valid) {
        page_table_l1[l1].entries[l2].entries = calloc(1 << L3_BITS, sizeof(L3_Entry));
        page_table_l1[l1].entries[l2].valid = 1;
    }

    page_table_l1[l1].entries[l2].entries[l3].frame_number = frame;
    page_table_l1[l1].entries[l2].entries[l3].valid = 1;
}

int translate_3level(unsigned long vaddr) {
    unsigned long l1 = (vaddr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & 0xFFFF;
    unsigned long l2 = (vaddr >> (L3_BITS + OFFSET_BITS)) & 0xFF;
    unsigned long l3 = (vaddr >> OFFSET_BITS) & 0xFF;

    if (!page_table_l1 || !page_table_l1[l1].valid) return -1;
    if (!page_table_l1[l1].entries[l2].valid) return -1;
    if (!page_table_l1[l1].entries[l2].entries[l3].valid) return -1;

    return page_table_l1[l1].entries[l2].entries[l3].frame_number;
}

/* ---------- INVERTED PAGE TABLE ---------- */

typedef struct {
    int process_id;
    int page_number;
    int valid;
} InvertedPageEntry;

InvertedPageEntry inverted_table[NUM_FRAMES];

int search_inverted_table(int pid, int page) {
    for (int i = 0; i < NUM_FRAMES; i++) {
        if (inverted_table[i].valid &&
            inverted_table[i].process_id == pid &&
            inverted_table[i].page_number == page) {
            return i;
        }
    }
    return -1;
}

void insert_inverted_table(int pid, int page, int frame) {
    inverted_table[frame].process_id = pid;
    inverted_table[frame].page_number = page;
    inverted_table[frame].valid = 1;
}

/* ---------- MAIN ---------- */

int main() {
    unsigned long vaddr = 0x123456789AB;
    allocate_3level(vaddr, 5);

    int frame = translate_3level(vaddr);
    if (frame >= 0)
        printf("Three-Level: Virtual Address %lx -> Frame %d\n", vaddr, frame);
    else
        printf("Three-Level: Page Fault\n");

    insert_inverted_table(1, 10, 3);
    int found = search_inverted_table(1, 10);
    if (found >= 0)
        printf("Inverted Page Table: PID 1 Page 10 -> Frame %d\n", found);
    else
        printf("Inverted Page Table: Page Fault\n");

    return 0;
}
