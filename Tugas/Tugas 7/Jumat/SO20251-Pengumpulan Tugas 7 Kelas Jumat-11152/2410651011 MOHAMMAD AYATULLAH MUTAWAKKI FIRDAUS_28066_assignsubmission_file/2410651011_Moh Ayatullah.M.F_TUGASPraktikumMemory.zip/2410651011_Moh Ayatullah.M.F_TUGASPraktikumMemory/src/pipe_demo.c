#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main() {
 int pipefd[2]; // pipefd[0] = read, pipefd[1] = write
 pid_t pid;
 char write_msg[] = "Hello dari Parent!";
 char read_msg[100];

 if (pipe(pipefd) == -1) {
   perror("Pipe gagal");
   return 1;
 }

 pid = fork();

 if (pid == 0) {
   close(pipefd[1]); // Child hanya baca
   read(pipefd[0], read_msg, sizeof(read_msg));
   printf("Child menerima: %s\n", read_msg);
   close(pipefd[0]);
 } else {
   close(pipefd[0]); // Parent hanya tulis
   printf("Parent mengirim: %s\n", write_msg);
   write(pipefd[1], write_msg, strlen(write_msg) + 1);
   close(pipefd[1]);
   wait(NULL);
 }

 return 0;
}
