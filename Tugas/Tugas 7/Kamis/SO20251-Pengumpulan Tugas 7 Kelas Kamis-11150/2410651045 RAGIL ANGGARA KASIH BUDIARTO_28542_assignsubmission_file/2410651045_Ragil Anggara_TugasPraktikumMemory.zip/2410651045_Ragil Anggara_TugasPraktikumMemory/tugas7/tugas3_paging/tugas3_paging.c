#include <stdio.h>

#define MAX_FRAMES 5
#define MAX_PAGES  20
#define REF_LEN    20

// ================= STATISTICS =================
typedef struct {
    int total_accesses;
    int page_faults;
    int page_hits;
    float hit_ratio;
    int disk_writes;
} PageStatistics;

// ================= GLOBAL =================
int frames[MAX_FRAMES];
int page_table[50];
int last_used[MAX_FRAMES];
int fifo_index = 0;

// ================= UTIL =================
void init_system(int frame_count) {
    for (int i = 0; i < frame_count; i++) {
        frames[i] = -1;
        last_used[i] = 0;
    }
    for (int i = 0; i < 50; i++)
        page_table[i] = -1;

    fifo_index = 0;
}

void display_frames(int frame_count) {
    for (int i = 0; i < frame_count; i++) {
        if (frames[i] == -1)
            printf(" - ");
        else
            printf(" %d ", frames[i]);
    }
}

// ================= FIFO =================
int fifo_page_replacement(int new_page, int frame_count) {
    int victim = frames[fifo_index];

    if (victim != -1)
        page_table[victim] = -1;

    frames[fifo_index] = new_page;
    page_table[new_page] = fifo_index;

    fifo_index = (fifo_index + 1) % frame_count;
    return victim;
}

// ================= LRU =================
int lru_page_replacement(int new_page, int frame_count, int time) {
    int lru = 0;
    for (int i = 1; i < frame_count; i++) {
        if (last_used[i] < last_used[lru])
            lru = i;
    }

    int victim = frames[lru];
    if (victim != -1)
        page_table[victim] = -1;

    frames[lru] = new_page;
    page_table[new_page] = lru;
    last_used[lru] = time;

    return victim;
}

// ================= SIMULATION =================
void simulate_fifo(int ref[], int frame_count) {
    PageStatistics stats = {0};

    printf("\n=== FIFO PAGE REPLACEMENT ===\n");
    printf("Step Ref | Frames           | Fault\n");
    printf("-----------------------------------\n");

    for (int i = 0; i < REF_LEN; i++) {
        int page = ref[i];
        stats.total_accesses++;

        printf("%3d  %3d |", i + 1, page);

        if (page_table[page] != -1) {
            stats.page_hits++;
            display_frames(frame_count);
            printf(" |  NO\n");
        } else {
            stats.page_faults++;
            fifo_page_replacement(page, frame_count);
            display_frames(frame_count);
            printf(" | YES\n");
        }
    }

    stats.hit_ratio =
        (float)stats.page_hits / stats.total_accesses;

    printf("\nFIFO Statistics:\n");
    printf("Page Faults : %d\n", stats.page_faults);
    printf("Page Hits   : %d\n", stats.page_hits);
    printf("Hit Ratio   : %.2f\n", stats.hit_ratio);
}

void simulate_lru(int ref[], int frame_count) {
    PageStatistics stats = {0};

    printf("\n=== LRU PAGE REPLACEMENT ===\n");
    printf("Step Ref | Frames           | Fault\n");
    printf("-----------------------------------\n");

    for (int i = 0; i < REF_LEN; i++) {
        int page = ref[i];
        stats.total_accesses++;

        printf("%3d  %3d |", i + 1, page);

        if (page_table[page] != -1) {
            stats.page_hits++;
            last_used[page_table[page]] = i;
            display_frames(frame_count);
            printf(" |  NO\n");
        } else {
            stats.page_faults++;
            lru_page_replacement(page, frame_count, i);
            display_frames(frame_count);
            printf(" | YES\n");
        }
    }

    stats.hit_ratio =
        (float)stats.page_hits / stats.total_accesses;

    printf("\nLRU Statistics:\n");
    printf("Page Faults : %d\n", stats.page_faults);
    printf("Page Hits   : %d\n", stats.page_hits);
    printf("Hit Ratio   : %.2f\n", stats.hit_ratio);
}

// ================= MAIN =================
int main() {
    int reference_string[REF_LEN] = {
        7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
        0, 3, 2, 1, 2, 0, 1, 7, 0, 1
    };

    int frame_count = 4;

    printf("Reference String:\n");
    for (int i = 0; i < REF_LEN; i++)
        printf("%d ", reference_string[i]);
    printf("\nFrames: %d\n", frame_count);
    // FIFO
    init_system(frame_count);
    simulate_fifo(reference_string, frame_count);
    // LRU
    init_system(frame_count);
    simulate_lru(reference_string, frame_count);
    return 0;
}
