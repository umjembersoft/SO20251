#include <stdio.h>
#include <stdlib.h>

/* =====================================================
   KONFIGURASI THREE-LEVEL PAGE TABLE
   ===================================================== */

#define L1_BITS 16
#define L2_BITS 8
#define L3_BITS 8
#define OFFSET_BITS 12

#define L1_SIZE (1 << L1_BITS)
#define L2_SIZE (1 << L2_BITS)
#define L3_SIZE (1 << L3_BITS)

#define PAGE_SIZE (1 << OFFSET_BITS)

/* =====================================================
   STRUKTUR THREE-LEVEL PAGE TABLE
   ===================================================== */

typedef struct {
    int frame_number;
    int valid;
    int read;
    int write;
    int execute;
} L3_Entry;

typedef struct {
    L3_Entry *entries;
    int valid;
} L2_Entry;

typedef struct {
    L2_Entry *entries;
    int valid;
} L1_Entry;

/* Page table level 1 */
L1_Entry *page_table;

/* =====================================================
   THREE-LEVEL PAGE TABLE FUNCTIONS
   ===================================================== */

/* Alokasi page */
void allocate_3level(unsigned long virtual_addr, int frame) {
    int l1 = (virtual_addr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & ((1 << L1_BITS) - 1);
    int l2 = (virtual_addr >> (L3_BITS + OFFSET_BITS)) & ((1 << L2_BITS) - 1);
    int l3 = (virtual_addr >> OFFSET_BITS) & ((1 << L3_BITS) - 1);

    /* Alokasi L2 jika belum ada */
    if (!page_table[l1].valid) {
        page_table[l1].entries = calloc(L2_SIZE, sizeof(L2_Entry));
        page_table[l1].valid = 1;
    }

    /* Alokasi L3 jika belum ada */
    if (!page_table[l1].entries[l2].valid) {
        page_table[l1].entries[l2].entries = calloc(L3_SIZE, sizeof(L3_Entry));
        page_table[l1].entries[l2].valid = 1;
    }

    /* Isi entry L3 */
    L3_Entry *entry = &page_table[l1].entries[l2].entries[l3];
    entry->frame_number = frame;
    entry->valid = 1;
    entry->read = entry->write = entry->execute = 1;
}

/* Translasi alamat virtual → fisik */
int translate_3level(unsigned long virtual_addr) {
    int l1 = (virtual_addr >> (L2_BITS + L3_BITS + OFFSET_BITS)) & ((1 << L1_BITS) - 1);
    int l2 = (virtual_addr >> (L3_BITS + OFFSET_BITS)) & ((1 << L2_BITS) - 1);
    int l3 = (virtual_addr >> OFFSET_BITS) & ((1 << L3_BITS) - 1);
    int offset = virtual_addr & ((1 << OFFSET_BITS) - 1);

    if (!page_table[l1].valid ||
        !page_table[l1].entries[l2].valid ||
        !page_table[l1].entries[l2].entries[l3].valid) {
        return -1; // PAGE FAULT
    }

    int frame = page_table[l1].entries[l2].entries[l3].frame_number;
    return (frame << OFFSET_BITS) | offset;
}

/* =====================================================
   INVERTED PAGE TABLE
   ===================================================== */

#define NUM_FRAMES 64

typedef struct {
    int process_id;
    int page_number;
    int valid;
} InvertedPageEntry;

InvertedPageEntry inverted_table[NUM_FRAMES];

/* Cari page pada inverted table */
int search_inverted_table(int pid, int page_num) {
    for (int i = 0; i < NUM_FRAMES; i++) {
        if (inverted_table[i].valid &&
            inverted_table[i].process_id == pid &&
            inverted_table[i].page_number == page_num) {
            return i; // frame ditemukan
        }
    }
    return -1; // PAGE FAULT
}

/* Masukkan page ke inverted table */
void insert_inverted_table(int pid, int page_num, int frame) {
    inverted_table[frame].process_id = pid;
    inverted_table[frame].page_number = page_num;
    inverted_table[frame].valid = 1;
}

/* =====================================================
   DEMO PROGRAM
   ===================================================== */

int main() {
    unsigned long virtual_addr = 0x123456789ABC;
    int physical_addr;

    printf("=== THREE-LEVEL PAGE TABLE DEMO ===\n");

    /* Alokasi page table level 1 */
    page_table = calloc(L1_SIZE, sizeof(L1_Entry));

    /* Mapping virtual address ke frame */
    allocate_3level(virtual_addr, 42);

    physical_addr = translate_3level(virtual_addr);
    if (physical_addr == -1) {
        printf("Page Fault pada alamat %lx\n", virtual_addr);
    } else {
        printf("Virtual Address : 0x%lx\n", virtual_addr);
        printf("Physical Address: 0x%x\n", physical_addr);
    }

    printf("\n=== INVERTED PAGE TABLE DEMO ===\n");

    int pid = 1;
    int page_num = 5;
    int frame = 10;

    insert_inverted_table(pid, page_num, frame);

    int found_frame = search_inverted_table(pid, page_num);
    if (found_frame == -1) {
        printf("Page Fault (PID=%d, Page=%d)\n", pid, page_num);
    } else {
        printf("Page ditemukan → Frame %d (PID=%d, Page=%d)\n",
               found_frame, pid, page_num);
    }

    return 0;
}
