#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_PROCESSES 10
#define PHYSICAL_MEMORY 1024   // MB
#define SIMULATION_TIME 100

typedef enum {
    FIFO,
    LRU,
    PRIORITY
} SwapStrategy;

typedef struct {
    int pid;
    int size;           // MB
    int priority;       // Semakin kecil = prioritas rendah
    int in_memory;      // 1 = di memory, 0 = swapped out
    int swap_count;
    time_t last_access;
    time_t load_time;
} Process;

/* ================== GLOBAL ================== */
Process processes[MAX_PROCESSES];
int used_memory = 0;
int swap_out_count = 0;
int swap_in_count = 0;

/* ================== FUNCTION PROTOTYPES ================== */
void init_processes();
void access_process(int pid);
void swap_out(Process *p);
void swap_in(Process *p);
Process* select_victim(SwapStrategy strategy);
void simulate(SwapStrategy strategy);

/* ================== IMPLEMENTATION ================== */

void init_processes() {
    srand(time(NULL));
    for (int i = 0; i < MAX_PROCESSES; i++) {
        processes[i].pid = i;
        processes[i].size = 50 + rand() % 151; // 50–200 MB
        processes[i].priority = rand() % 10;   // 0 = rendah
        processes[i].in_memory = 0;
        processes[i].swap_count = 0;
        processes[i].last_access = time(NULL);
        processes[i].load_time = time(NULL);
    }
}

void swap_out(Process *p) {
    if (p->in_memory) {
        p->in_memory = 0;
        used_memory -= p->size;
        p->swap_count++;
        swap_out_count++;
        printf("SWAP OUT -> PID %d (size=%d MB)\n", p->pid, p->size);
    }
}

void swap_in(Process *p) {
    while (used_memory + p->size > PHYSICAL_MEMORY) {
        Process *victim = select_victim(FIFO);
        if (victim == NULL) break;
        swap_out(victim);
    }

    p->in_memory = 1;
    used_memory += p->size;
    p->load_time = time(NULL);
    p->last_access = time(NULL);
    swap_in_count++;

    printf("SWAP IN  -> PID %d (size=%d MB)\n", p->pid, p->size);
}

Process* select_victim(SwapStrategy strategy) {
    Process *victim = NULL;

    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (!processes[i].in_memory) continue;

        if (victim == NULL) {
            victim = &processes[i];
            continue;
        }

        switch (strategy) {
            case FIFO:
                if (processes[i].load_time < victim->load_time)
                    victim = &processes[i];
                break;

            case LRU:
                if (processes[i].last_access < victim->last_access)
                    victim = &processes[i];
                break;

            case PRIORITY:
                if (processes[i].priority < victim->priority)
                    victim = &processes[i];
                break;
        }
    }
    return victim;
}

void access_process(int pid) {
    Process *p = &processes[pid];
    if (!p->in_memory) {
        swap_in(p);
    }
    p->last_access = time(NULL);
}

void simulate(SwapStrategy strategy) {
    swap_in_count = swap_out_count = 0;
    used_memory = 0;

    printf("\n===== SIMULATION START (%s) =====\n",
        strategy == FIFO ? "FIFO" :
        strategy == LRU ? "LRU" : "PRIORITY");

    for (int t = 0; t < SIMULATION_TIME; t++) {
        int pid = rand() % MAX_PROCESSES;
        access_process(pid);
    }

    printf("\n===== RESULT =====\n");
    printf("Swap In Count  : %d\n", swap_in_count);
    printf("Swap Out Count : %d\n", swap_out_count);
}

/* ================== MAIN ================== */

int main() {
    init_processes();

    simulate(FIFO);
    simulate(LRU);
    simulate(PRIORITY);

    return 0;
}
