#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// ===== Forward Declarations =====
int main();
void print_memory_layout();
void func1();
void func2();
void recursive_func(int level);

// ===== Global Variables =====
int global_var = 100;        // Data segment
int uninitialized_var;      // BSS segment

// ===== Functions =====
void func1() {}
void func2() {}

void recursive_func(int level) {
    int local_var = level;

    printf(" Level %d local_var address: %p\n",
           level, (void *)&local_var);

    if (level < 2) {
        recursive_func(level + 1);
    }
}

void print_memory_layout() {
    // ===== Static Array (Data Segment) =====
    static int static_array[5] = {1, 2, 3, 4, 5};

    // ===== Heap Allocation =====
    int *dynamic_array = (int *)malloc(5 * sizeof(int));
    int *block1 = (int *)malloc(sizeof(int));
    int *block2 = (int *)malloc(sizeof(int));

    // ===== Stack Variable =====
    int stack_var = 50;

    // ===== String Literal =====
    char *str_literal = "Hello Memory Layout";

    printf("\n=== ENHANCED MEMORY LAYOUT ===\n\n");

    // ===== Text Segment =====
    printf("1. Text Segment:\n");
    printf(" main() address  : %p\n", (void *)main);
    printf(" func1() address : %p\n", (void *)func1);
    printf(" func2() address : %p\n\n", (void *)func2);

    // ===== Data Segment =====
    printf("2. Data Segment:\n");
    printf(" global_var address       : %p\n", (void *)&global_var);
    printf(" static_array[0] address  : %p\n", (void *)&static_array[0]);
    printf(" string literal address   : %p\n\n", (void *)str_literal);

    // ===== BSS Segment =====
    printf("3. BSS Segment:\n");
    printf(" uninitialized_var address: %p\n\n", (void *)&uninitialized_var);

    // ===== Heap Segment =====
    printf("4. Heap:\n");
    printf(" dynamic_array[0] address : %p\n", (void *)&dynamic_array[0]);
    printf(" malloc block 1 address   : %p\n", (void *)block1);
    printf(" malloc block 2 address   : %p\n\n", (void *)block2);

    // ===== Stack Segment =====
    printf("5. Stack:\n");
    printf(" stack_var address        : %p\n\n", (void *)&stack_var);

    // ===== Recursive Stack =====
    printf("6. Stack (Recursive Calls):\n");
    recursive_func(0);

    // ===== Free Heap =====
    free(dynamic_array);
    free(block1);
    free(block2);
}

int main() {
    printf("Program dimulai...\n");
    printf("PID: %d\n", getpid());

    print_memory_layout();

    printf("\nTekan Enter untuk melihat memory map...\n");
    getchar();

    char cmd[100];
    sprintf(cmd, "cat /proc/%d/maps", getpid());
    system(cmd);

    return 0;
}
