#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MEMORY_SIZE 1000
#define MAX_BLOCKS 50

typedef struct {
    int start;
    int size;
    int free;
} Block;

Block memory[MAX_BLOCKS];
int block_count = 1;
int last_alloc_index = 0;

/* ================= INITIALIZATION ================= */
void init_memory() {
    memory[0].start = 0;
    memory[0].size = MEMORY_SIZE;
    memory[0].free = 1;
    block_count = 1;
    last_alloc_index = 0;
}

/* ================= SPLIT BLOCK ================= */
void split_block(int i, int size) {
    Block new_block;
    new_block.start = memory[i].start + size;
    new_block.size = memory[i].size - size;
    new_block.free = 1;

    memory[i].size = size;
    memory[i].free = 0;

    for (int j = block_count; j > i + 1; j--)
        memory[j] = memory[j - 1];

    memory[i + 1] = new_block;
    block_count++;
}

/* ================= ALGORITHMS ================= */
int first_fit(int size) {
    for (int i = 0; i < block_count; i++) {
        if (memory[i].free && memory[i].size >= size) {
            split_block(i, size);
            return 1;
        }
    }
    return 0;
}

int best_fit(int size) {
    int best = -1;
    for (int i = 0; i < block_count; i++)
        if (memory[i].free && memory[i].size >= size)
            if (best == -1 || memory[i].size < memory[best].size)
                best = i;

    if (best != -1) {
        split_block(best, size);
        return 1;
    }
    return 0;
}

int worst_fit(int size) {
    int worst = -1;
    for (int i = 0; i < block_count; i++)
        if (memory[i].free && memory[i].size >= size)
            if (worst == -1 || memory[i].size > memory[worst].size)
                worst = i;

    if (worst != -1) {
        split_block(worst, size);
        return 1;
    }
    return 0;
}

int next_fit(int size) {
    int i = last_alloc_index;
    int scanned = 0;

    while (scanned < block_count) {
        if (memory[i].free && memory[i].size >= size) {
            split_block(i, size);
            last_alloc_index = i;
            return 1;
        }
        i = (i + 1) % block_count;
        scanned++;
    }
    return 0;
}

/* ================= DEALLOCATE ================= */
void deallocate(int index) {
    memory[index].free = 1;
}

/* ================= FRAGMENTATION ================= */
void calculate_fragmentation() {
    int total_free = 0;
    int largest_free = 0;
    int holes = 0;

    for (int i = 0; i < block_count; i++) {
        if (memory[i].free) {
            total_free += memory[i].size;
            holes++;
            if (memory[i].size > largest_free)
                largest_free = memory[i].size;
        }
    }

    double frag = total_free == 0 ? 0 :
        (double)(total_free - largest_free) / total_free * 100;

    printf("Total Free Space   : %d\n", total_free);
    printf("Largest Free Block : %d\n", largest_free);
    printf("Free Holes         : %d\n", holes);
    printf("Fragmentation      : %.2f %%\n", frag);
}

/* ================= BENCHMARK ================= */
void benchmark_test(int algo) {
    clock_t start = clock();
    int fail = 0;

    init_memory();

    int (*alloc)(int) = first_fit;
    if (algo == 2) alloc = best_fit;
    if (algo == 3) alloc = worst_fit;
    if (algo == 4) alloc = next_fit;

    if (!alloc(100)) fail++;
    if (!alloc(200)) fail++;
    if (!alloc(300)) fail++;
    if (!alloc(250)) fail++;
    if (!alloc(150)) fail++;

    deallocate(1);
    deallocate(3);

    if (!alloc(180)) fail++;
    if (!alloc(220)) fail++;
    if (!alloc(100)) fail++;

    clock_t end = clock();
    double time_us = (double)(end - start) * 1000000 / CLOCKS_PER_SEC;

    printf("Execution Time     : %.2f us\n", time_us);
    calculate_fragmentation();
    printf("Failed Allocations : %d\n", fail);
}

/* ================= MAIN ================= */
int main() {
    printf("\n=== MEMORY ALLOCATOR BENCHMARK ===\n\n");

    printf("[ First-Fit ]\n");
    benchmark_test(1);

    printf("\n[ Best-Fit ]\n");
    benchmark_test(2);

    printf("\n[ Worst-Fit ]\n");
    benchmark_test(3);

    printf("\n[ Next-Fit ]\n");
    benchmark_test(4);

    return 0;
}
