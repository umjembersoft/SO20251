#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/statvfs.h>
#include <unistd.h>
#include <errno.h>

#define BUFFER_SIZE 1024  // Ukuran buffer untuk aman

void read_and_parse_proc_file(const char *file_path, void (*parse_func)(char*)) {
    FILE *file = fopen(file_path, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }
    char buffer[BUFFER_SIZE];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        parse_func(buffer);  // Parsing manual
    }
    fclose(file);
}

void parse_loadavg(char *line) {  // Ubah parameter menjadi non-const
    char *temp_line = strdup(line);  // Buat salinan non-const untuk strtok()
    if (temp_line) {
        char *token = strtok(temp_line, " ");  // Sekarang aman
        if (token) printf("CPU Load Average: %s\n", token);
        free(temp_line);  // Bebaskan memori
    }
}

void parse_cpuinfo(char *line) {
    // Kode parsing tetap sama
    static int core_count = 0;
    if (strstr(line, "model name") != NULL) {
        printf("Model: %s", line + 13);
    } else if (strstr(line, "cpu cores") != NULL) {
        core_count = atoi(strstr(line, ":") + 1);
        printf("Cores: %d\n", core_count);
    } else if (strstr(line, "cpu MHz") != NULL) {
        printf("Frequency: %s", line + 9);
    }
}

// Fungsi lain (parse_meminfo, parse_net_dev, list_running_processes) tetap sama

void list_running_processes() {
    DIR *dir = opendir("/proc");
    if (dir == NULL) {
        perror("Error opening /proc");
        return;
    }
    struct dirent *entry;
    char path[256];  // Buffer tetap 256, tapi gunakan snprintf()
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR && atoi(entry->d_name) > 0) {
            snprintf(path, sizeof(path), "/proc/%s/comm", entry->d_name);  // Ganti sprintf dengan snprintf
            FILE *comm_file = fopen(path, "r");
            if (comm_file) {
                char comm[100];
                fgets(comm, sizeof(comm), comm_file);
                fclose(comm_file);
                printf("PID: %s, Name: %s", entry->d_name, comm);
                snprintf(path, sizeof(path), "/proc/%s/status", entry->d_name);  // snprintf untuk aman
                FILE *status_file = fopen(path, "r");
                if (status_file) {
                    char status_line[100];
                    while (fgets(status_line, sizeof(status_line), status_file)) {
                        if (strstr(status_line, "State")) {
                            printf("Status: %s", status_line);
                        }
                    }
                    fclose(status_file);
                }
            }
        }
    }
    closedir(dir);
}

// Fungsi main() tetap sama, hanya panggil parse_loadavg dengan perbaikan

int main() {
    // Kode utama...
    read_and_parse_proc_file("/proc/loadavg", parse_loadavg);  // Sekarang aman
    // Lanjutkan seperti sebelumnya
    return 0;
}
