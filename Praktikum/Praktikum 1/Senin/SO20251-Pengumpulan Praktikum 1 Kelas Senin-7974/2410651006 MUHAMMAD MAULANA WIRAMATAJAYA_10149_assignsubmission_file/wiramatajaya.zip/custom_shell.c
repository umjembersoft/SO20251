#include <stdio.h>       // Untuk fgets(), printf(), fopen(), dll.
#include <stdlib.h>      // Untuk exit(), malloc(), free()
#include <string.h>      // Untuk strtok(), strcmp()
#include <unistd.h>      // Untuk fork(), execvp(), chdir(), getcwd()
#include <sys/types.h>   // Untuk pid_t
#include <sys/wait.h>    // Untuk waitpid()
#include <fcntl.h>       // Untuk open()
#include <errno.h>       // Untuk error handling

#define MAX_HISTORY 5       // Maksimal 5 command untuk history
#define MAX_INPUT 1024      // Maksimal panjang input

char *history[MAX_HISTORY];  // Array untuk menyimpan history command
int history_count = 0;       // Jumlah command saat ini

void add_to_history(char *command) {
    if (history_count >= MAX_HISTORY) {
        free(history[0]);  // Hapus yang paling lama
        for(int i = 0; i < MAX_HISTORY - 1; i++) {
            history[i] = history[i + 1];
        }
        history_count = MAX_HISTORY - 1;
    }
    history[history_count] = strdup(command);  // Salin command ke array
    history_count++;
}

void print_history() {
    for(int i = history_count > MAX_HISTORY ? history_count - MAX_HISTORY : 0; i < history_count; i++) {
        printf("%d: %s", i + 1, history[i]);
    }
}

int main() {
    char input[MAX_INPUT];
    while(1) {  // Loop utama shell
        printf("wira shell >");  // Prompt shell
        if (fgets(input, MAX_INPUT, stdin) == NULL) {  // fgets() digunakan untuk membaca input user
            break;  // Keluar jika EOFz
        }
        input[strcspn(input, "\n")] = 0;  // Hapus newline
        add_to_history(input);  // Tambahkan ke history

        char *args[64];  // Array untuk menyimpan argument command
        char *token = strtok(input, " ");  // strtok() digunakan untuk parsing input secara manual
                                           // Alasan: Memisahkan command dan argument berdasarkan spasi
        int arg_count = 0;
        int is_background = 0;  // Flag untuk background process
        int has_pipe = 0;       // Flag untuk piping
        int pipe_fds[2];        // Array untuk pipe file descriptors
        char *redirect_type = NULL;  // Untuk redirection: '>', '<', '>>'
        char *redirect_file = NULL;  // File untuk redirection

        while(token != NULL) {
            if (strcmp(token, "&") == 0) {
                is_background = 1;  // Deteksi background process
            } else if (strcmp(token, "|") == 0) {
                has_pipe = 1;  // Deteksi piping
            } else if (strcmp(token, ">") == 0 || strcmp(token, "<") == 0 || strcmp(token, ">>") == 0) {
                redirect_type = token;  // Deteksi redirection
                redirect_file = strtok(NULL, " ");  // Ambil file redirection
            } else {
                args[arg_count++] = token;  // Tambahkan argument
            }
            token = strtok(NULL, " ");
        }
        args[arg_count] = NULL;  // Akhiri array dengan NULL untuk execvp()

        if (arg_count > 0) {
            if (strcmp(args[0], "cd") == 0) {  // Built-in cd
                if (arg_count >= 2) chdir(args[1]);  // chdir() digunakan untuk ganti direktori
                else printf("cd: missing argument\n");
            } else if (strcmp(args[0], "exit") == 0) {  // Built-in exit
                exit(0);
            } else if (strcmp(args[0], "pwd") == 0) {  // Built-in pwd
                char cwd[256];
                getcwd(cwd, sizeof(cwd));  // getcwd() digunakan untuk dapatkan direktori saat ini
                printf("%s\n", cwd);
            } else if (strcmp(args[0], "echo") == 0) {  // Built-in echo
                for(int i = 1; i < arg_count; i++) printf("%s ", args[i]);
                printf("\n");
            } else if (strcmp(args[0], "riwayat") == 0) {  // Built-in history
                print_history();
            } else {
                pid_t pid = fork();  // fork() digunakan untuk membuat process child
                if (pid == 0) {  // Di child process
                    if (has_pipe) {
                        pipe(pipe_fds);  // pipe() digunakan untuk membuat pipe
                        pid_t pipe_pid = fork();
                        if (pipe_pid == 0) {  // Child untuk command pertama (e.g., ls)
                            dup2(pipe_fds[1], STDOUT_FILENO);  // dup2() digunakan untuk redirect stdout ke pipe
                                                               // Alasan: Mengubah file descriptor agar output command pertama masuk ke pipe
                            close(pipe_fds[0]);  // Tutup ujung baca
                            execvp(args[0], args);  // Eksekusi command
                        } else {
                            dup2(pipe_fds[0], STDIN_FILENO);  // Redirect stdin ke pipe
                            close(pipe_fds[1]);  // Tutup ujung tulis
                            char *pipe_args[64];
                            memcpy(pipe_args, args + 1, sizeof(args));  // Ambil command kedua (e.g., grep)
                            execvp(args[1], pipe_args);  // Eksekusi command kedua
                        }
                    }
                    if (redirect_type) {
                        if (strcmp(redirect_type, ">") == 0) {
                            int fd = open(redirect_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                            dup2(fd, STDOUT_FILENO);  // Redirect stdout ke file
                            close(fd);
                        } else if (strcmp(redirect_type, "<") == 0) {
                            int fd = open(redirect_file, O_RDONLY);
                            dup2(fd, STDIN_FILENO);  // Redirect stdin ke file
                            close(fd);
                        } else if (strcmp(redirect_type, ">>") == 0) {
                            int fd = open(redirect_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
                            dup2(fd, STDOUT_FILENO);
                            close(fd);
                        }
                    }
                    execvp(args[0], args);  // Eksekusi command eksternal
                    perror("Command not found");  // Handle error
                    exit(1);
                } else {
                    if (!is_background) waitpid(pid, NULL, 0);  // Tunggu jika foreground
                }
            }
        }
    }
    return 0;
}