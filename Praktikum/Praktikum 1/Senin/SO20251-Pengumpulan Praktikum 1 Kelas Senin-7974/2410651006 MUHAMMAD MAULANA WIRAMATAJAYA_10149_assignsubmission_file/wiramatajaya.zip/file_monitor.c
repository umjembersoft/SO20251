#include <sys/inotify.h>  // Untuk system call inotify
#include <stdio.h>        // Untuk I/O seperti printf(), fopen()
#include <stdlib.h>       // Untuk exit()
#include <string.h>       // Untuk string operations
#include <time.h>         // Untuk time() dan localtime()
#include <unistd.h>       // Untuk read(), close(), getpid()
#include <signal.h>       // Untuk signal handling
#include <fcntl.h>        // Untuk open()
#include <errno.h>        // Untuk error handling

#define EVENT_SIZE  (sizeof(struct inotify_event))  // Ukuran satu event
#define BUF_LEN     (1024 * (EVENT_SIZE + 16))      // Buffer untuk multiple event

int inotify_fd;  // File descriptor inotify
int log_fd;      // File descriptor untuk file log

void handler(int sig) {  // Handler untuk SIGTERM
    if (sig == SIGTERM) {
        printf("Menerima SIGTERM, melakukan cleanup...\n");
        if (inotify_fd > 0) {
            close(inotify_fd);  // close() digunakan untuk menutup file descriptor inotify
                                 // Alasan: Untuk membersihkan resource dan menghindari kebocoran
        }
        if (log_fd > 0) {
            close(log_fd);  // close() untuk menutup file log
        }
        exit(0);  // exit() untuk keluar program secara bersih
    }
}

int main() {
    char buffer[BUF_LEN];  // Buffer untuk menyimpan event-event
    signal(SIGTERM, handler);  // signal() digunakan untuk mendaftarkan handler SIGTERM
                               // Alasan: Untuk menangani terminasi dan cleanup resource

    inotify_fd = inotify_init();  // inotify_init() digunakan untuk inisialisasi inotify
                                  // Alasan: Membuat file descriptor untuk memantau event
    if (inotify_fd < 0) {
        perror("inotify_init");
        exit(1);
    }

    char dir_path[256];  // Path direktori dari user
    printf("Masukkan direktori untuk dipantau (misal: /tmp/monitor_dir): ");
    scanf("%255s", dir_path);  // Baca input dari user

    int wd = inotify_add_watch(inotify_fd, dir_path, IN_CREATE | IN_MODIFY | IN_DELETE);
                                  // inotify_add_watch() digunakan untuk menambahkan watch pada direktori
                                  // Alasan: Memantau event IN_CREATE, IN_MODIFY, dan IN_DELETE
    if (wd < 0) {
        perror("inotify_add_watch");
        close(inotify_fd);
        exit(1);
    }

    log_fd = open("monitor.log", O_WRONLY | O_CREAT | O_APPEND, 0644);
             // open() digunakan untuk membuka/membuat file log
             // Alasan: Untuk menulis log event ke file teks
    if (log_fd < 0) {
        perror("open log file");
        close(inotify_fd);
        exit(1);
    }

    while(1) {  // Infinite loop untuk memantau event
        ssize_t len = read(inotify_fd, buffer, BUF_LEN);  // read() digunakan untuk membaca event dari file descriptor
                                                           // Alasan: Membaca buffer yang berisi satu atau lebih event inotify
        if (len < 0) {
            perror("read");
            continue;
        }

        int i = 0;
        while (i < len) {
            struct inotify_event *event = (struct inotify_event *) &buffer[i];
            /* Struktur inotify_event:
             * - wd: Watch descriptor, mengidentifikasi direktori yang dipantau.
             * - mask: Mask event, seperti IN_CREATE, IN_MODIFY, IN_DELETE.
             * - len: Panjang nama file (jika ada).
             * - name: Nama file yang terpengaruh (jika len > 0).
             * Bagaimana membaca buffer: read() mengisi buffer dengan satu atau lebih struct inotify_event.
             * Loop melalui buffer dengan offset i, tambahkan sizeof(event) + event->len untuk event berikutnya.
             */
            
            char event_type[20];
            if (event->mask & IN_CREATE) strcpy(event_type, "IN_CREATE");
            else if (event->mask & IN_MODIFY) strcpy(event_type, "IN_MODIFY");
            else if (event->mask & IN_DELETE) strcpy(event_type, "IN_DELETE");
            else continue;  // Hanya handle event yang diminta

            if (event->len > 0) {  // Jika ada nama file
                char *ext = strrchr(event->name, '.');  // Periksa ekstensi file
                if (ext && (strcmp(ext, ".txt") == 0 || strcmp(ext, ".log") == 0)) {
                    // Filter: Hanya log file dengan ekstensi .txt atau .log
                    time_t now = time(NULL);  // time() digunakan untuk mendapatkan waktu saat ini
                    struct tm *local = localtime(&now);  // localtime() digunakan untuk mengonversi waktu ke struct tm
                                                         // Alasan: Menghitung timestamp manual untuk log
                    char timestamp[50];
                    sprintf(timestamp, "%04d-%02d-%02d %02d:%02d:%02d", 
                            local->tm_year + 1900, local->tm_mon + 1, local->tm_mday,
                            local->tm_hour, local->tm_min, local->tm_sec);

                    char log_entry[512];
                    sprintf(log_entry, "[%s] [%s] [%s] [%d]\n", timestamp, event_type, event->name, getpid());
                                // getpid() digunakan untuk mendapatkan PID process yang melakukan logging
                                // Alasan: Tugas meminta PID process yang melakukan, di sini kita gunakan PID program ini sebagai approksimasi, karena inotify tidak menyediakan PID asli

                    write(log_fd, log_entry, strlen(log_entry));  // write() digunakan untuk menulis ke file log
                                                                  // Alasan: Untuk menyimpan event yang difilter ke file teks
                }
            }
            i += EVENT_SIZE + event->len;  // Pindah ke event berikutnya
        }
    }

    // Kode di bawah tidak akan tercapai karena infinite loop, tapi untuk completeness
    close(inotify_fd);
    close(log_fd);
    return 0;
}