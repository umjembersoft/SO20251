#include <unistd.h>       // Untuk system call seperti fork(), pipe(), read(), write()
#include <sys/wait.h>     // Untuk waitpid(), WIFEXITED(), WEXITSTATUS()
#include <sys/types.h>    // Untuk tipe data seperti pid_t
#include <stdio.h>        // Untuk fungsi I/O seperti printf(), scanf()
#include <stdlib.h>       // Untuk exit()
#include <string.h>       // Untuk string operations
#include <sys/time.h>     // Untuk gettimeofday()
#include <signal.h>       // Untuk signal handling

void handler(int sig) {   // Handler untuk SIGINT
    printf("Parent received SIGINT (signal %d). Menggunakan sebagai alternatif komunikasi untuk Child 3.\n", sig);
    // Sebagai alternatif, kirim sinyal ke Child 3 (misalnya, untuk memberi tahu atau hentikan)
    // Di sini, kita anggap PID Child 3 disimpan, tapi untuk sederhana, hanya cetak pesan.
    // Alasan: SIGINT di parent digunakan sebagai alternatif untuk berkomunikasi dengan Child 3,
    //         tanpa mengganggu pipe utama.
}

int main() {
    struct timeval start, end;  // Untuk mengukur waktu eksekusi
    pid_t pids[3];              // Array untuk menyimpan PID child
    int pipes_to_parent[3][2];  // Pipe unik per child: untuk child mengirim hasil ke parent
    int pipes_to_child[3][2];   // Pipe untuk parent mengirim input ke child
    int num_for_fact;           // Input untuk Child 1
    int limit_for_primes;       // Input untuk Child 2
    char string_for_reverse[100]; // Input untuk Child 3

    // Handler signal untuk parent
    if (signal(SIGINT, handler) == SIG_ERR) {  // signal() digunakan untuk mendaftarkan handler untuk SIGINT
        perror("sinyal");                      // Alasan: Untuk menangani SIGINT sebagai alternatif komunikasi dengan Child 3
        exit(1);
    }

    // Baca input dari user di parent
    printf("masukan angka untuk fiktorial: ");
    scanf("%d", &num_for_fact);
    printf("masukan batas bilangan prima: ");
    scanf("%d", &limit_for_primes);
    printf("masukan kata untuk di balik: ");
    scanf("%s", string_for_reverse);  // Note: scanf() hanya membaca hingga spasi; gunakan fgets() jika perlu string lengkap

    for(int i = 0; i < 3; i++) {  // Loop untuk membuat 3 pipe dan fork 3 child
        if (pipe(pipes_to_parent[i]) == -1) {  // pipe() digunakan untuk membuat pipe unik per child
            perror("err dari child ke parent");          // Alasan: Untuk komunikasi satu arah dari child ke parent
            exit(1);
        }
        if (pipe(pipes_to_child[i]) == -1) {   // pipe() digunakan untuk membuat pipe untuk parent ke child
            perror("err dari parent child");           // Alasan: Untuk mengirim input dari parent ke child
            exit(1);
        }

        pids[i] = fork();  // fork() digunakan untuk membuat process child baru
                           // Alasan: Untuk membuat process independen yang menjalankan tugas berbeda
        if (pids[i] == -1) {
            perror("fork");
            exit(1);
        }

        if (pids[i] == 0) {  // Di child process
            close(pipes_to_parent[i][0]);  // Tutup ujung baca pipe (karena child menulis)
            close(pipes_to_child[i][1]);   // Tutup ujung tulis pipe input (karena child membaca)

            if (i == 0) {  // Child 1: Hitung faktorial
                int input;
                read(pipes_to_child[i][0], &input, sizeof(int));  // read() digunakan untuk membaca input dari parent
                                                                   // Alasan: Untuk menerima data dari parent via pipe
                int fact = 1;
                for(int j = 1; j <= input; j++) fact *= j;
                write(pipes_to_parent[i][1], &fact, sizeof(int));  // write() digunakan untuk mengirim hasil ke parent
                                                                   // Alasan: Untuk mengirim hasil komputasi via pipe unik
            } else if (i == 1) {  // Child 2: Hitung bilangan prima
                int limit;
                read(pipes_to_child[i][0], &limit, sizeof(int));
                int count = 0;
                for(int j = 2; j <= limit; j++) {
                    int is_prime = 1;
                    for(int k = 2; k * k <= j; k++) {
                        if(j % k == 0) { is_prime = 0; break; }
                    }
                    if(is_prime) count++;
                }
                write(pipes_to_parent[i][1], &count, sizeof(int));
            } else if (i == 2) {  // Child 3: Balik string
                char str[100];
                read(pipes_to_child[i][0], str, sizeof(str));
                int len = strlen(str);
                char reversed[100];
                strcpy(reversed, str);
                for(int j = 0; j < len / 2; j++) {
                    char temp = reversed[j];
                    reversed[j] = reversed[len - 1 - j];
                    reversed[len - 1 - j] = temp;
                }
                write(pipes_to_parent[i][1], reversed, sizeof(reversed));
            }

            close(pipes_to_parent[i][1]);  // Tutup pipe setelah digunakan
            close(pipes_to_child[i][0]);
            exit(0);  // exit() digunakan untuk menghentikan child process
                      // Alasan: Untuk memberi tahu OS bahwa child selesai
        } else {  // Di parent process
            close(pipes_to_parent[i][1]);  // Tutup ujung tulis pipe (karena parent membaca)
            close(pipes_to_child[i][0]);   // Tutup ujung baca pipe input (karena parent menulis)

            // Kirim input ke child via pipe
            if (i == 0) {
                write(pipes_to_child[i][1], &num_for_fact, sizeof(int));
            } else if (i == 1) {
                write(pipes_to_child[i][1], &limit_for_primes, sizeof(int));
            } else if (i == 2) {
                write(pipes_to_child[i][1], string_for_reverse, sizeof(string_for_reverse));
            }
            close(pipes_to_child[i][1]);  // Tutup pipe setelah menulis
        }
    }

    // Parent menunggu setiap child selesai
    for(int i = 0; i < 3; i++) {
        gettimeofday(&start, NULL);  // gettimeofday() digunakan untuk mencatat waktu awal
                                     // Alasan: Untuk menghitung waktu eksekusi manual
        int status;
        waitpid(pids[i], &status, 0);  // waitpid() digunakan untuk menunggu child selesai
                                       // Alasan: Untuk menghindari zombie process dan mendapatkan status exit
        gettimeofday(&end, NULL);      // gettimeofday() untuk mencatat waktu akhir

        double time_taken = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;

        printf("Child PID: %d\n", pids[i]);
        if(WIFEXITED(status)) {  // WIFEXITED() digunakan untuk memeriksa apakah child keluar normal
                                 // Alasan: Untuk memverifikasi status exit child
            printf("status keluar : %d\n", WEXITSTATUS(status));  // WEXITSTATUS() untuk mendapatkan kode exit
        }
        printf("waktu eksekusi: %f seconds\n", time_taken);

        // Baca hasil dari pipe
        if (i == 0) {  // Child 1
            int result;
            read(pipes_to_parent[i][0], &result, sizeof(int));
            printf("hasil faktorial : %d\n", result);
        } else if (i == 1) {  // Child 2
            int result;
            read(pipes_to_parent[i][0], &result, sizeof(int));
            printf("bilangan prima : %d\n", result);
        } else if (i == 2) {  // Child 3
            char result[100];
            read(pipes_to_parent[i][0], result, sizeof(result));
            printf("Membalikan angka: %s\n", result);
        }
        close(pipes_to_parent[i][0]);  // Tutup pipe setelah membaca
    }

    return 0;
}